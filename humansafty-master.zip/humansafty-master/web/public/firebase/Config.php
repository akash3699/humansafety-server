<?php 
	define('DB_USERNAME','root');
	define('DB_PASSWORD','root');
	define('DB_NAME','humansafty');
	define('DB_HOST','mysql');

	//defined a new constant for firebase api key
	define('FIREBASE_API_KEY', 'AIzaSyBjE-cRBqb0vkge7MNKSkmFs5WWtMfi6ew');

	