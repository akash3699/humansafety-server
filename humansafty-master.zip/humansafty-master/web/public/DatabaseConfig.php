<?php

//Define your host here.
$HostName = "mysql";

//Define your database username here.
$HostUser = "root";

//Define your database password here.
$HostPass = "root";

//Define your database name here.
$DatabaseName = "humansafty";

?>