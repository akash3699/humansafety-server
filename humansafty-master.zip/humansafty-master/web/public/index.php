<?php
// require_once 'dbconnect.php';
?><!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Docker <?php echo "Hello"; ?></title>
    </head>
    <body>
      <h1>Docker <?php echo "World"; ?></h1>
      <?php
?>
    </body>
</html>
